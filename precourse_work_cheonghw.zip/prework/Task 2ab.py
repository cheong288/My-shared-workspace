import Soln2

listA = [1, 2, 3, 4, 2, 2]
keyA1 = 2
keyA2 = 5

print("answer for task 2a :")
Soln2.find_and_replace(listA, keyA1, keyA2)

listB = ["apple", "banana", "apple"]
keyB1 = "apple"
keyB2 = "orange"

print("answer for task 2b :")
Soln2.find_and_replace(listB, keyB1, keyB2)
