def find_first_negative(mylist):

    i = 0
    lena = len(mylist)
    flag = 0

    while i < lena :
        if flag == 0:
            if mylist[i] < 0:
                flag = 1
                x = mylist[i]
                return(x)
        i += 1

    if flag == 0:
        print("No negatives")
