import Soln4

word1 = "Hello World"
r_word1 = Soln4.string_reverse(word1)
print(r_word1)

word2 = "Python"
r_word2 = Soln4.string_reverse(word2)
print(r_word2)

