import Soln5

a = 10
b = 2
print("answer for task 5a: ", end="")
Soln5.check_divisibility(a, b)

a = 7
b = 3
print("answer for task 5b :", end="")
Soln5.check_divisibility(a, b)
