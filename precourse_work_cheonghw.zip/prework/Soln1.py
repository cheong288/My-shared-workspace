def swap(x,y):

    if type(x)==int:
        if type(y)==int:
            m = 0
            m = y
            y = x
            x = m
            print(x,y)
    else:
        print(-1)