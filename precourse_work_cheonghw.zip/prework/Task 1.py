import Soln1

x="apple"
y=10
print("answer for task 1 Qna: ",end="") 
Soln1.swap(x,y)

x=9
y=17
print("answer for task 1 Qnb: ",end="")
Soln1.swap(x,y)
