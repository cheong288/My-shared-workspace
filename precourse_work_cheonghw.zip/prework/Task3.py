import Soln3

dct = { }

key = "name"
value = "Alice"
Soln3.update_dictionary(dct, key, value)

key = "age"
value = 25
Soln3.update_dictionary(dct, key, value)

key = "age"
value = 26
Soln3.update_dictionary(dct, key, value)