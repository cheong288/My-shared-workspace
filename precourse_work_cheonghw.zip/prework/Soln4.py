def string_reverse(s_word):
    
    x = s_word[::-1]
    return(x)
