def update_dictionary(mydict, key, value):

    if key in mydict:
        print("original key-value :",end="")
        print(key, mydict.get(key))
        mydict.update({key: value})
        print("updated key-value :",end="")
        print(key, mydict.get(key))
    else:
       mydict.update({key: value}) 

    return mydict
