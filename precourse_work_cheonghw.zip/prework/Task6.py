import Soln6

list1 = [3, 5, -1, 7, -2, 8]
m = Soln6.find_first_negative(list1)
print("answer to Task6a :", end="")
print(m)

list2 = [2, 10, 7, 0]
n = Soln6.find_first_negative(list2)
print("answer to Task6b :", end="")
print(n)
