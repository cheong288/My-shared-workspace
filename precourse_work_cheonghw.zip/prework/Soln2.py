def find_and_replace(list1, key1, key2):

    m = len(list1)
    i = 0
    while i < m:
        if list1[i] == key1:
            list1[i] = key2
        i += 1
    print(list1)
