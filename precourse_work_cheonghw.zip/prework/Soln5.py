def check_divisibility(Num, Divisor):

    x = Num % Divisor

    if x == 0:
        print("true")
    else:
        print("false")
